=== Plugin Name ===
Contributors: Fortisthemes, Afrothemes
Donate link: https://thepixeltribe.com
Tags: comments, spam
Requires at least: 4.3
Tested up to: 5.6
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WordPress portfolio plugins designers & photographers, This plugin adds galleries, portfolio CPT & custom homepage for all our portfolio themes

== Description ==

WordPress portfolio plugins designers & photographers, This plugin adds galleries, portfolio CPT & custom homepage for all our portfolio themes


== Installation ==



1. Upload `pro-portfolio.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Create a page, call it home, under page attributes select 'Porfolio'
4. Set this page as the static homepage.
5. Add portfolio items under the 'Portfolio' > Add new Menu.  Remember to include a featured image and title, the rest is optional.


== Frequently Asked Questions ==

= How do I Set Up The Homepage? =

Create a page, under page templates select 'portfolio', go to settings > reading, select static front page, then select the page you just created.

= Does this plugin support Gutenberg? =

No, If you want drag and drop blocks, upgrade to swishpro

== Screenshots ==


== Changelog ==

= 1.0 =
* intial release

